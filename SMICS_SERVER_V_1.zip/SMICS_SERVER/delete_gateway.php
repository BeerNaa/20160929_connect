<?php
session_start();
include ("connect.php");

$getGatewayCheckBox = $_POST["select_gateway"];
$session = $_SESSION['userID'];

for($i=0; $i< count($getGatewayCheckBox); $i++){
  if($getGatewayCheckBox[$i]!=''){
    $sql = "DELETE FROM gateway WHERE G_ID='$getGatewayCheckBox[$i]'";
    $result = mysql_query($sql);
    // echo $sql;
    // echo $getGatewayCheckBox[$i];
  }
}

if($result){
  echo "<meta http-equiv='refresh' content='0; url=gateway.php'>" ;
  exit();
}
echo "<meta http-equiv='refresh' content='0; url=gateway.php'>" ;
?>
