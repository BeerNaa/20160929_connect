<?php
session_start();
include ("connect.php");

$getGName = $_POST["gname_ins"];
$getGKey = $_POST["gkey_ins"];
$getGAddress = $_POST["gaddress_ins"];
$session_userID = $_SESSION['userID'];

// ID Generate for 7 Digits
        $sql = "SELECT MAX(G_ID) FROM gateway WHERE USER_ID = $session_userID";
        $result = mysql_query($sql);
		    $row = mysql_fetch_array($result);

        $str = $row[0];
        $gid_user = substr($str,0,7);

        if (COUNT($row[0]) < 1) {
          $valG_ID = $gid_user."001";
        }
        else {
          $gid_count = substr($str,7,3);
          $valG_ID = $gid_count+1;
          $getLenght = strlen($valG_ID);
          if($getLenght == 1){
            $valG_ID = '00'.$valG_ID;
          } else if ($getLenght == 2){
            $valG_ID = '0'.$valG_ID;
          }
        }
        $valG_ID = $gid_user.$valG_ID;
		    // if(COUNT($row[0]) < 1) {
		    //         $valID = "G-"+$gid_user+"-001";
		    //     } else {
		    //         $str = $row[0];
		    //         $mod = substr($str,0,2);
		    //         $num = substr($str,2,6)+1;
		    //         $genID = $mod.$num;
		    //         $getLenght = strlen($genID);
		    //              if($getLenght == 3){
		    //               $valID = $mod.'000'.$num;
		    //             } else if ($getLenght == 4){
		    //               $valID = $mod.'00'.$num;
		    //             } else if ($getLenght == 5){
		    //               $valID = $mod.'0'.$num;
		    //         }
		    //       }

$sql = "INSERT INTO gateway (G_ID, G_NAME, G_KEY, PIPES, USER_ID)
        VALUES ('$valG_ID', '$getGName', '$getGKey','$getGAddress', '$session_userID')";
$result = mysql_query($sql);
if($result){
  echo "<meta http-equiv='refresh' content='0; url=gateway.php'>" ;
  exit();
}
else {
  echo "<meta http-equiv='refresh' content='0; url=gateway.php'>" ;
}

?>
