<?php
session_start();
include ("connect.php");

$getSName = $_POST["sname_ins"];
$getSKey = $_POST["skey_ins"];
$getSAddress = $_POST["saddress_ins"];
$getGID = $_POST["sensor_GID_ins"];

// ID Generate for 7 Digits
        $sql = "SELECT MAX(S_ID) FROM sensor_node WHERE G_ID = '$getGID'";
        $result = mysql_query($sql);
		    $row = mysql_fetch_array($result);

        $str = $row[0];
        $sid_mode = substr($str,0,11);

        if (COUNT($row[0]) < 1) {
          $valS_ID = $sid_mode."01";
        }
        else {
          $sid_count = substr($str,11,2);
          $valS_ID = $sid_count+1;
          $valS_ID = '0'.$valS_ID;
        }
        $valS_ID = $sid_mode.$valS_ID;

		    // if(COUNT($row[0]) < 1) {
		    //         $valID = "S-0001";
		    //     } else {
		    //         $str = $row[0];
		    //         $mod = substr($str,0,2);
		    //         $num = substr($str,2,6)+1;
		    //         $genID = $mod.$num;
		    //         $getLenght = strlen($genID);
		    //              if($getLenght == 3){
		    //               $valID = $mod.'000'.$num;
		    //             } else if ($getLenght == 4){
		    //               $valID = $mod.'00'.$num;
		    //             } else if ($getLenght == 5){
		    //               $valID = $mod.'0'.$num;
		    //         }
		    //       }
$sql = "INSERT INTO sensor_node (S_ID, S_NAME, S_KEY, G_ID)
        VALUES ('$valS_ID', '$getSName', '$getSKey', '$getGID')";
$result = mysql_query($sql);
if($result){
  echo "<meta http-equiv='refresh' content='0; url=sensor_node.php'>" ;
  exit();
}
else {
  echo "<meta http-equiv='refresh' content='0; url=sensor_node.php'>" ;
  exit();
}

?>
