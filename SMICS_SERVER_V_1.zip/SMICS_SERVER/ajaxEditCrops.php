<?php

// require_once ("secure.php"); // Page Security
include ("connect.php");

$getCallID= (isset($_POST['cropsID'])) ? $_POST['cropsID'] : '';
$sql = "SELECT crops.*, TYPE_NAME FROM crops, crops_type WHERE CROPS_ID = '$getCallID' AND crops.TYPE_ID = crops_type.TYPE_ID";
$result = mysql_query($sql);
$row_crops = mysql_fetch_array($result);
?>
<form method="post">
<div class="box-body">
  <input type="hidden" name="cropsID" value="<?php echo $getCallID; ?>">
    <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <h4>ชื่อพืช</h4>
            <input class="form-control" type="text" name="cropsName" id="cropsName"
            title="ชื่อพืช" required="" value="<?php echo $row_crops["CROPS_NAME"]; ?>">
          </div>
        </div>

        <div class="col-md-6">
          <h4>ชนิดของพืช</h4>
        </label>

        <?php
          $sql = "SELECT * FROM crops_type";
          $result = mysql_query($sql);
        ?>
        <select class="form-control" id="select" required="" name="type_crops" >
          <option value="<?php echo $row[TYPE_ID]; ?>"><?php echo "กรุณาระบุชนิดของพืช"; ?></option>
          <?php
            while($row = mysql_fetch_array($result)){ ?>
            <option value="<?php echo $row[TYPE_ID]; ?>"><?php echo $row[TYPE_NAME]; ?></option>
            <?php } ?>
        </select>
        </div>
        </div>
        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <h4>ปริมาณความชื้น</h4>
              <input class="form-control" type="text" name="moisture" id="moisture"
              title="ปริมาณความชื้น" required="" value="<?php echo $row_crops["MOISTURE"]; ?>">
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <h4>ฤดูกาล (วัน)</h4>
              <input class="form-control" type="text" name="season" id="season"
              title="ชื่อพืช" required="" value="<?php echo $row_crops["SEASON"]; ?>">
            </div>
          </div>
        </div>
    </div><!-- /.div row -->
</form>
