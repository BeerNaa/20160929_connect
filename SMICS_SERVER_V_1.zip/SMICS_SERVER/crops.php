<?php
session_start();
if($_SESSION['username'] == ''){
  echo "<meta http-equiv='refresh' content='0; url=index.php'>" ;
  exit();
}
include('header.php');
include('sidebar.php');
include('connect.php');
?>
<title>SMICS | CROPS</title>
<style>
body {
      margin:0;
      overflow: auto;
      height: 100%;
    }
    .test[style] {
      padding-right:0 !important;
    }
    .test.modal-open {
      overflow: auto;
    }
</style>

<!-- Bootstrap 3.3.5 -->
<script src="bootstrap/js/bootstrap.min.js"></script>
<!-- jQuery 2.1.4 -->
<script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
<!-- iCheck -->
<script src="plugins/iCheck/icheck.min.js"></script>

<script type="text/javascript">
function checkAll(bx) {
  var cbs = document.getElementsByTagName('input');
  for(var i=0; i < cbs.length; i++) {
    if(cbs[i].type == 'checkbox') {
      cbs[i].checked = bx.checked;
    }
  }
}

$('#mmm').on('show.bs.modal', function (e) {

     $('body').addClass('test');
});


$(function(){
 $('.push').click(function(){
    var valID = $(this).attr('id');
     $.ajax({
        type : 'POST',
         url : 'ajaxEditCrops.php',
        data : 'cropsID='+valID,
     success : function(data){
      //  alert("OK");
       console.log(data);
            $('#valData').show().html(data);
         }
       });
  });
});
</script>
<script>



function myFunction() {
    $('#valEditCrops').modal('show');
  //  $('.modal.in')
  //  $( '.modal' ).remove();
    document.body.removeAttribute("style");
}
function myFunction2() {
    $('#valEditCrops').modal('hide');
  //  $('.modal.in')
  //  $( '.modal' ).remove();
    document.body.removeAttribute("style");
}

function myFunction3() {
    $('#myModal').modal('show');
  //  $('.modal.in')
  //  $( '.modal' ).remove();
    document.body.removeAttribute("style");
}
function myFunction4() {
    $('#myModal').modal('hide');
  //  $('.modal.in')
  //  $( '.modal' ).remove();
    document.body.removeAttribute("style");
}
</script>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Profile Crops
    </h1>
    <div style="padding-top:20px;"></div>
    <a class="btn btn-primary" onclick="myFunction3()"><i class="fa fa-plus" aria-hidden="true"></i>&nbsp;&nbsp;เพิ่มข้อมูลพืชของฉัน</a>
    <div style="padding-top:20px;"></div>
  </section>

  <!-- Main content -->
  <form action="delete_crops.php" method="post">
<?php
    /* PAGE SPLIT FOR SQL QUERY */
    // REQUESTED PAGE
    $requestedPage = isset($_GET['page']) ? intval($_GET['page']) : 1;
    $session = $_SESSION["userID"];
    $session_status = $_SESSION['status'];
    if($session_status == "Administrator"){
      $check = "SELECT COUNT(*) FROM crops ";
    }else {
      $check = "SELECT COUNT(*) FROM crops WHERE USER_ID = '$session' OR USER_ID IN (SELECT USER_ID FROM user WHERE STATUS = 1)";
    }
    // GET THE ROW COUNT
    $sqlRowCount = mysql_query($check);
    $resultRowCount = mysql_fetch_row($sqlRowCount);
    $listCount = $resultRowCount[0];
    $rowPerPage = 15;
    // PAGECOUNT CALCULATE

    $pageCount = ceil($listCount / $rowPerPage);
    $firstShown = ($requestedPage - 1) * $rowPerPage;

    if($session_status == "Administrator"){
      $sql = "SELECT crops.CROPS_ID, crops.CROPS_NAME, MOISTURE, SEASON, crops_type.TYPE_NAME, USER_ID FROM crops LEFT JOIN crops_type ON crops_type.TYPE_ID = crops.TYPE_ID LIMIT $firstShown, $rowPerPage";
    }else {
      $sql = "SELECT crops.CROPS_ID, crops.CROPS_NAME, MOISTURE, SEASON, crops_type.TYPE_NAME, USER_ID FROM crops LEFT JOIN crops_type ON crops_type.TYPE_ID = crops.TYPE_ID WHERE USER_ID = '$session' OR USER_ID IN (SELECT USER_ID FROM user WHERE STATUS = 1) LIMIT $firstShown, $rowPerPage";
    }
    $sqlQueryList = mysql_query($sql); ?>

                                  <table class="table table-striped table-hover ">
                                    <thead>
                                      <tr>
                                        <th width="100px;"><center>เลือกทั้งหมด<br><input type="checkbox" onclick="checkAll(this)" ></center></th>
                                        <?php
                                          if ($session_status == "Administrator") { ?>
                                            <th width="100px;" style="text-align: center;">รหัสพืช</th>
                                          <?php }
                                          else {
                                            ?>
                                            <th width="100px;" style="text-align: center;">ลำดับ</th>
                                            <?php
                                          }
                                        ?>
                                        <th width="250px;" style="text-align: center;">ชนิดของพืช</th>
                                        <th width="200px;" style="text-align: center;">ชื่อพืช</th>
                                        <th width="150px;" style="text-align: center;">ปริมาณความชื้น</th>
                                        <th width="100px;" style="text-align: center;">ฤดูกาล (วัน)</th>
                                        <th width="100px;" style="text-align: center;">แก้ไข</th>
                                      </tr>
                                    </thead>
                                    <tbody >
    <?php $countList = 1;
    $count = 1;
       $offset = $firstShown+1;
       $session_userID = $_SESSION['userID'];
    while($row = mysql_fetch_assoc($sqlQueryList)) { ?>
      <tr>
        <td>
          <center>
            <?php
              if ($session_status == "Administrator") { ?>
                <input type="checkbox" name="select[]" value = "<?php echo $row["CROPS_ID"]; ?>">
              <?php }
              else {
                if($row['USER_ID'] == $session_userID){
                  ?>
                    <input type="checkbox" name="select[]" value = "<?php echo $row["CROPS_ID"]; ?>">
                  <?php
                } else {
                    echo " ";
                  }
              }
           ?>
          </center>
        </td>
        <?php
          if ($session_status == "Administrator") { ?>
            <td style="text-align: center;"><?php echo $row["CROPS_ID"]; ?></td>
          <?php }
          else {
            ?>
            <td style="text-align: center;"><?php echo $offset; ?></td>
            <?php
          }
        ?>
        <td style="text-align: center;"><?php echo $row["TYPE_NAME"]; ?></td>
        <td><?php echo $row["CROPS_NAME"]; ?></td>
        <td style="text-align: center;"><?php echo $row["MOISTURE"]; ?></td>
        <td style="text-align: center;"><?php echo $row["SEASON"];?></td>
        <!-- <td> -->
          <td style="text-align: center;">
            <?php
              if ($session_status == "Administrator") { ?>
                <a class="btn btn-warning btn-xs push" data-toggle="modal" data-target="#valEditCrops" id="<?php echo $row["CROPS_ID"]; ?>"><i class="fa fa-pencil"></i>&nbsp;&nbsp;แก้ไข</a>
              <?php }
              else {
                if($row['USER_ID'] == $session_userID){
                  ?>
                  <a class="btn btn-warning btn-xs push" data-toggle="modal" data-target="#valEditCrops" id="<?php echo $row["CROPS_ID"]; ?>"><i class="fa fa-pencil"></i>&nbsp;&nbsp;แก้ไข</a>
                  <?php
                } else {
                    echo "";
                  }
              }
            ?>
          <!-- </td> -->
        </td>
      </tr>
    		                    <?php $countList++; $offset++; $count++; }
    							if(($countList - 1) < "1"){
    								echo '<td colspan="6" align="center">';
    							    echo '<small>NO DATA TO SHOW</small>';
    							    echo '</td>';
    							    }
    /* END OF PAGE SPLIT FOR SQL QUERY */ ?>
    </tbody></table>

    <?php // WRITE THE PAGE LINKS
    echo '<center><ul class="pagination">';
    for($i = 1; $i <= $pageCount; $i++) {
        if($i == $requestedPage) { ?>
            <li <?php if($requestedPage == $i): ?> class="active"<?php endif; ?>>
            <a href="crops.php?page=<?php echo $i;?>"><?php echo $i;?></a></li>
        <?php } else { ?>
      		<li <?php if($requestedPage == $i): ?> class="active"<?php endif; ?>>
      		<a href="crops.php?page=<?php echo $i;?>"><?php echo $i;?></a></li>
        <?php }
    }
    echo '</ul></center>'; ?>

  <!-- <section class="content-header"> -->
  <section class="content-header">
    <button type="submit" class="btn btn-danger" onclick="return confirm('คุณแน่ใจหรือไม่ที่จะลบข้อมูล?');"><i class="fa fa-trash"></i>&nbsp;&nbsp;ลบรายการที่เลือก</button>
    <div style="padding-top:30px;"></div>
  </section>
  <!-- </section> -->
</form>


  <!-- <section class="content"> -->
    <!-- Small boxes (Stat box) -->

  <!-- </section> -->
  <!-- /.content -->
</div><!-- /.content-wrapper -->
<?php
  include('footer.php');
?>

<div class="modal fade modal-primary" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title">เพิ่มข้อมูลพืชของฉัน</h4>
      </div>
      <form id="modal_form" action="insert_crops.php" method="post">
      <div class="modal-body">
        <div class="row">
          <div class="col-md-6">
            <label class="">
              <h4>ชื่อพืช</h4>
            </label>
            <input type="text" class="form-control" placeholder="กรุณาระบุชื่อพืช" name="crops_name" required="">
            <label class="">
            </div>
            <div class="col-md-6" style="padding-top:5px;">
              <h4>ชนิดของพืช</h4>
            </label>

            <?php
              $sql = "select * from crops_type";
              $result = mysql_query($sql);
            ?>
            <select class="form-control" id="select" required="" name="type_crops" >
              <option value=""><?php echo "กรุณาระบุชนิดของพืช"; ?></option>
              <?php
                while($row = mysql_fetch_array($result)){ ?>
                <option value="<?php echo $row[TYPE_ID]; ?>"><?php echo $row[TYPE_NAME]; ?></option>
                <?php } ?>
            </select>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6">
          <label class="" style="padding-top:5px;">
            <h4>ปริมาณความชื้น</h4>
          </label>
          <input type="text" class="form-control" placeholder="กรุณาระบุค่าปริมาณความชื้น (เปอร์เซ็น)" name="moisture_ins" required="">
        </div>
        <div class="col-md-6">
          <label class="" style="padding-top:5px;">
            <h4>ฤดูกาล (วัน)</h4>
          </label>
          <input type="text" class="form-control" placeholder="กรุณาระบุระยะเวลาในการปลูก (วัน)" name="season_ins" required="">
        </div>
        </div>
      </div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-success">บันทึกการทำรายการ</button>
        <button type="button" class="btn btn-danger" onclick="myFunction4()">ยกเลิก</button>
      </div>
    </form>
    </div>
  </div>

<!-- Edit crops -->
<form action="edit_crops.php" method="post">
<div class="modal fade" id="valEditCrops" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title"><i class="fa fa-pencil"></i>&nbsp;&nbsp;แก้ไขข้อมูลพืช</h4>
      </div>
      <div class="modal-body table-responsive">
        <form role="form" name="editCatalogue" action="editCatalogue.php" method="post" enctype="multipart/form-data">
          <?php echo '<input type="hidden" name="instant" value="editCatalogue">'; //Form Instant ?>

          <div id="valData"></div>

          <div class="pull-right padding">
            <button type="submit" id="submit" name="submit" class="btn btn-success"> ดำเนินการแก้ไข</button>
            <button type="button" id="cancle" name="cancle" class="btn btn-danger" onclick="myFunction2()"> ยกเลิก</button>
          </div>
        </form>
      </div>
    </div>
    </div>
    </div>
    </form>
