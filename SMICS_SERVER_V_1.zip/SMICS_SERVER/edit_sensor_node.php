<?php
session_start();
include ("connect.php");

$getSID = $_POST["S_ID"];
$getSName = $_POST["S_NAME_edit"];
$getSKey = $_POST["S_KEY_edit"];

$sql = "UPDATE `sensor_node` SET `S_NAME`='$getSName',`S_KEY`='$getSKey' WHERE S_ID = '$getSID'";
$result = mysql_query($sql);

if($result){
  echo "<meta http-equiv='refresh' content='0; url=sensor_node.php'>" ;
  exit();
}
echo "<meta http-equiv='refresh' content='0; url=sensor_node.php'>" ;
?>
