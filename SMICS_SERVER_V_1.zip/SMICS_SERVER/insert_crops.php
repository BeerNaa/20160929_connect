<?php
session_start();
include ("connect.php");

$getCropsName = $_POST["crops_name"];
$getTypeCrops = $_POST["type_crops"];
$getMoisture = $_POST["moisture_ins"];
$getSeason = $_POST["season_ins"];
$session_userID = $_SESSION['userID'];

// ID Generate for 7 Digits
        $sql = "SELECT MAX(CROPS_ID) FROM crops WHERE USER_ID = $session_userID";
        $result = mysql_query($sql);
		    $row = mysql_fetch_array($result);

        $str = $row[0];
        $cid_user = substr($str,0,9);

        if (COUNT($row[0]) < 1) {
          $valC_ID = $cid_user."001";
        }
        else {
          $cid_count = substr($str,9,3);
          $valC_ID = $cid_count+1;
          $getLenght = strlen($valC_ID);
          if($getLenght == 1){
            $valC_ID = '00'.$valC_ID;
          } else if ($getLenght == 2){
            $valC_ID = '0'.$valC_ID;
          }
        }
        $valC_ID = $cid_user.$valC_ID;

		    // if(COUNT($row[0]) < 1) {
		    //         $valID = "C-0001";
		    //     } else {
		    //         $str = $row[0];
		    //         $mod = substr($str,0,2);
		    //         $num = substr($str,2,6)+1;
		    //         $genID = $mod.$num;
		    //         $getLenght = strlen($genID);
		    //              if($getLenght == 3){
		    //               $valID = $mod.'000'.$num;
		    //             } else if ($getLenght == 4){
		    //               $valID = $mod.'00'.$num;
		    //             } else if ($getLenght == 5){
		    //               $valID = $mod.'0'.$num;
		    //         }
		    //       }
$session = $_SESSION['userID'];
$sql = "INSERT INTO crops (CROPS_ID, CROPS_NAME, MOISTURE, SEASON, USER_ID, TYPE_ID) VALUES ('$valC_ID', '$getCropsName', '$getMoisture','$getSeason', '$session', '$getTypeCrops')";
$result = mysql_query($sql);
if($result){
  echo "<meta http-equiv='refresh' content='0; url=crops.php'>" ;
  exit();
}

?>
