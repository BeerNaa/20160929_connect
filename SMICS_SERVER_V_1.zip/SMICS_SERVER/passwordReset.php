<?php

include ("connect.php");

$getPassOriginal= (isset($_POST['passOriginal'])) ? $_POST['passOriginal'] : '';
$getPass = md5($getPassOriginal);
$getPassword= (isset($_POST['password'])) ? $_POST['password'] : '';
$getUser= (isset($_POST['user'])) ? $_POST['user'] : '';
$sql = "SELECT * FROM user WHERE password = '$getPass' AND userID = '$getUser'";
$result = mysql_query($sql);
$row = mysql_fetch_array($result);

if(!$row) {
  echo "commit<br>";
  echo ",cancel,".$sql;
} else {

  $tempPassword = md5($getPassword);
  $sqlUpdatePassword = "UPDATE user SET password = '$tempPassword' WHERE userID = '$getUser'";
  $resultUpdatePassword = mysql_query($sqlUpdatePassword);
  $rowUpdatePassword = mysql_fetch_array($resultUpdatePassword);

  echo "commit<br>";
  echo ",success,".$sql." ".$tempPassword." ".$getPassword;
}

?>
