<?php
session_start();
include ("connect.php");

$getSensorNodeCheckBox = $_POST["select_sensor"];
$session = $_SESSION['userID'];

for($i=0; $i< count($getSensorNodeCheckBox); $i++){
  if($getSensorNodeCheckBox[$i]!=''){
    $sql = "DELETE FROM sensor_node WHERE S_ID = '$getSensorNodeCheckBox[$i]'";
    $result = mysql_query($sql);
    // echo $sql;
    // echo $getGatewayCheckBox[$i];
  }
}

if($result){
  echo "<meta http-equiv='refresh' content='0; url=sensor_node.php'>" ;
  exit();
}
echo "<meta http-equiv='refresh' content='0; url=sensor_node.php'>" ;
?>
