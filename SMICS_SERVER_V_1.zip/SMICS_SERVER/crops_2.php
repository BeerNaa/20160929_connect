<?php
session_start();
include('header.php');
include('sidebar.php');
include('connect.php');

?>


<!-- jQuery 2.1.4 -->
<script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
<!-- Bootstrap 3.3.5 -->
<script src="bootstrap/js/bootstrap.min.js"></script>
<!-- iCheck -->
<script src="plugins/iCheck/icheck.min.js"></script>

<script type="text/javascript">
function checkAll(bx) {
  var cbs = document.getElementsByTagName('input');
  for(var i=0; i < cbs.length; i++) {
    if(cbs[i].type == 'checkbox') {
      cbs[i].checked = bx.checked;
    }
  }
}

$(function(){
 $('.push').click(function(){
    var valID = $(this).attr('id');
     $.ajax({
        type : 'POST',
         url : 'ajaxEditCrops.php',
        data : 'cropsID='+valID,
     success : function(data){
      //  alert("OK");
       console.log(data);
            $('#valData').show().html(data);
         }
       });
  });
});
</script>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Profile Crops
    </h1>
    <div style="padding-top:20px;"></div>
    <a class="btn btn-primary" data-toggle="modal" href="#myModal"><i class="fa fa-plus" aria-hidden="true"></i>&nbsp;&nbsp;เพิ่มข้อมูลพืชของฉัน</a>
    <div style="padding-top:20px;"></div>
  </section>

  <!-- Main content -->
  <form action="delete_crops.php" method="post">
  <table class="table table-striped table-hover ">
    <thead>
      <tr>
        <th width="150px;"><center>เลือกทั้งหมด<br><input type="checkbox" onclick="checkAll(this)" ></center></th>
        <th>ลำดับ</th>
        <th>ชนิดของพืช</th>
        <th>ชื่อพืช</th>
        <th>ปริมาณความชื้น</th>
        <th>ฤดูกาล (วัน)</th>
        <th>แก้ไข</th>
      </tr>
    </thead>
    <tbody>
    <?php
      $count = 1;
      $session = $_SESSION['userID'];
      if($session == 'A-0001'){
        $sql = "select cropsID, cropsName, moisture, season, typeName from crops, crops_type where crops_type.typeID = crops.typeID";
        $result = mysql_query($sql);
      } else {
        $sql = "select cropsID, cropsName, moisture, season, typeName from crops, crops_type where userID = '$session' && crops_type.typeID = crops.typeID";
        $result = mysql_query($sql);
      }

      while($row = mysql_fetch_array($result)){
    ?>
      <tr>
        <td><center><input type="checkbox" name="select[]" value = "<?php echo $row["cropsID"]; ?>"></center></td>
        <td><?php echo $count; ?></td>
        <td><?php echo $row["typeName"]; ?></td>
        <td><?php echo $row["cropsName"]; ?></td>
        <td><?php echo $row["moisture"]; ?></td>
        <td><?php echo $row["season"];?></td>
        <td>
          <a class="btn btn-warning btn-xs push" data-toggle="modal" data-target="#valEditCrops" id="<?php echo $row["cropsID"]; ?>"><i class="fa fa-pencil"></i>&nbsp;&nbsp;แก้ไข</a>
        </td>
      </tr>
    <?php $count++; } ?>
    </tbody>
  </table>
  <!-- <section class="content-header"> -->
  <section class="content-header">
    <button type="submit" class="btn btn-danger" onclick="return confirm('คุณแน่ใจหรือไม่ที่จะลบข้อมูล?');"><i class="fa fa-trash"></i>&nbsp;&nbsp;ลบรายการที่เลือก</button>
    <div style="padding-top:30px;"></div>
  </section>
  <!-- </section> -->
</form>


  <!-- <section class="content"> -->
    <!-- Small boxes (Stat box) -->

  <!-- </section> -->
  <!-- /.content -->
</div><!-- /.content-wrapper -->
<?php
include('footer.php');
?>

<div class="modal fade modal-primary" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title">เพิ่มข้อมูลพืชของฉัน</h4>
      </div>
      <form id="modal_form" action="insert_crops.php" method="post">
      <div class="modal-body">
        <div class="row">
          <div class="col-md-6">
            <label class="">
              <h4>ชื่อพืช</h4>
            </label>
            <input type="text" class="form-control" placeholder="กรุณาระบุชื่อพืช" name="crops_name" required="">
            <label class="">
            </div>
            <div class="col-md-6" style="padding-top:5px;">
              <h4>ชนิดของพืช</h4>
            </label>

            <?php
              $sql = "select * from crops_type";
              $result = mysql_query($sql);
            ?>
            <select class="form-control" id="select" required="" name="type_crops" >
              <option value=""><?php echo "กรุณาระบุชนิดของพืช"; ?></option>
              <?php
                while($row = mysql_fetch_array($result)){ ?>
                <option value="<?php echo $row[typeID]; ?>"><?php echo $row[typeName]; ?></option>
                <?php } ?>
            </select>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6">
          <label class="" style="padding-top:5px;">
            <h4>ปริมาณความชื้น</h4>
          </label>
          <input type="text" class="form-control" placeholder="กรุณาค่าปริมาณความชื้น (เปอร์เซ็น)" name="moisture_ins" required="">
        </div>
        <div class="col-md-6">
          <label class="" style="padding-top:5px;">
            <h4>ฤดูกาล (วัน)</h4>
          </label>
          <input type="text" class="form-control" placeholder="กรุณาระยะเวลาในการปลูก (วัน)" name="season_ins" required="">
        </div>
        </div>
      </div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-success">บันทึกการทำรายการ</button>
        <button type="button" class="btn btn-danger" data-dismiss="modal">ยกเลิก</button>
      </div>
    </form>
    </div>
  </div>

<!-- Edit crops -->
<form action="edit_crops.php" method="post">
<div class="modal fade" id="valEditCrops" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title"><i class="fa fa-pencil"></i>&nbsp;&nbsp;แก้ไขข้อมูลพืช</h4>
      </div>
      <div class="modal-body table-responsive">
        <form role="form" name="editCatalogue" action="editCatalogue.php" method="post" enctype="multipart/form-data">
          <?php echo '<input type="hidden" name="instant" value="editCatalogue">'; //Form Instant ?>

          <div id="valData"></div>

          <div class="pull-right padding">
            <button type="submit" id="submit" name="submit" class="btn btn-success"> ดำเนินการแก้ไข</button>
            <button type="button" id="cancle" name="cancle" class="btn btn-danger" data-toggle="modal" data-dismiss="modal"> ยกเลิก</button>
          </div>
        </form>
      </div>
    </div>
    </div>
    </div>
    </form>
