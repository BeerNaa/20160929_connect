<?php
session_start();
include ("connect.php");

$getUsername = $_POST["username"];
$getPassword = $_POST["password"];
$password_encrypt = md5($getPassword);
$sql = "select user.*, status.* from user, status where user.E_MAIL = '$getUsername' AND user.PASSWORD = '$password_encrypt' AND user.STATUS = status.STATUS_ID";
$result = mysql_query($sql);
while($row = mysql_fetch_array($result)){
    if($row["E_MAIL"] == $getUsername && $row["PASSWORD"] == $password_encrypt){
            $_SESSION['username'] = $getUsername;
            $_SESSION['userID'] = $row["USER_ID"];
            $_SESSION['status'] = $row["STATUS"];
            $_SESSION['firstName'] = $row["FIRSTNAME"];
            $_SESSION['lastName'] = $row["LASTNAME"];
            // $_SESSION['permission'] = $rowTutor["tutor_permission"];
            // echo "<meta http-equiv='refresh' content='0; url=home.php'>" ;
            // exit();
            echo "(=Y";
        }
}
if(!$row){
        $_SESSION['action'] = "denied";
        // echo "<meta http-equiv='refresh' content='0; url=index.php'>" ;
        echo "(=N";
        // exit();
}


?>
