<?php session_start(); ?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>SIS-PROJECT | LOG IN</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css"> -->
    <!-- Ionicons -->
    <!-- <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css"> -->
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/iCheck/square/blue.css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>

    body {
          /*css for full size background image*/
          background: url(http://localhost/smics/images/wallpaper_index.jpg) no-repeat center center fixed;
          -webkit-background-size: cover;
          -moz-background-size: cover;
          -o-background-size: cover;
          background-size: cover;

          height: 100%;
          /*background-color: #060;*/
          color: #fff;
          /*text-align: center;*/
          text-shadow: 0 1px 3px rgba(0,0,0,.5);
      }

    </style>
  </head>

<script>
function check() {
  $(document).ready(function() {
              var valUsername = $('#username').val();
              var valPassword = $('#password').val();
              var dataString = "username=" + valUsername + "&password=" + valPassword;

                $.ajax({
                    type: "POST",
                    url: "auth.php",
                    data: dataString,
                    success:function(data) {
                     console.log(data);
                     var val = jQuery.trim(data);
                     var str = val.split('(=');
                     console.log(str[1]);
                     if(str[1] == "N"){
                      //  alert(str[1]);
                      $("#alert").modal('show');
                     } else {
                       <?php
                       /*
                       $_SESSION['username'] = str[2];
                       $_SESSION['userID'] = str[3];
                       */ ?>
                       location = "home.php";
                     }
                    }
                }); return false;
      });
  }
</script>

  <body>
    <div class = "container">

      <div class = "row">
        <div class = "col-md-8">

        </div>
        <div class = "col-md-4">
          <div id="loginDiv" style="padding-top:120px;">
          <form id="login">
            <div class="form-group">
              <?php
              /*if($_SESSION['action']=="denied"){
                echo '
                <div class="alert alert-danger alert-dismissible">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                <h4><i class="icon fa fa-ban"></i>แจ้งเตือน!</h4>
                                &nbsp;&nbsp;&nbsp;ชื่อผู้ใช้งาน หรือ รหัสผ่าน ไม่ถูกต้อง
                              </div>
                ';
                session_unset($_SESSION['action']);
              }*/
              ?>
              <label class="">
                อีเมล์ผู้ใช้งาน
              </label>
              <input type="text" class="form-control" placeholder="กรุณากรอกอีเมล์ผู้ใช้งาน" name="username" id="username">
            </div>
            <div class="form-group">
              <label class="">
                รหัสผ่าน
              </label>
              <input type="password" class="form-control" placeholder="กรุณากรอกรหัสผ่าน" name="password" id="password">
            </div>
            <div class="form-group">
              <button type="button" id="signin" class="btn btn-primary btn-block btn-flat" onclick="check()">เข้าสู่ระบบ</button>
            </div>
            <div class = "row">
              <div class = "col-md-6">
                <input type="checkbox" class="iCheck-helper" name="remember_me" value="true">&nbsp;&nbsp;จำฉันไว้ในระบบ<br>
              </div>
              <div class = "col-md-6">
                <a data-toggle="modal" href="#myModal">ลืมรหัสผ่าน</a>
              </div>
            </div>
            <div class = "row">
              <div class = "col-md-12" style="padding-top:20px;">
                <a href="register_form.php">สมัครสมาชิก</a>
              </div>
            </div>
          </form>
        </div>
        </div>
      </div>
    </div>


  </body>
</html>
<!-- <form action="forget_pass.php"> -->
<div class="modal fade modal-primary" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h3 class="modal-title">ลืมรหัสผ่าน</h3>
      </div>
      <form id="modal_form" action="forget_pass.php" method="post">
      <div class="modal-body">
        <div class="form-group">
          <label class="" style="padding-top:20px;">
            <h4>กรุณากรอก อีเมล หรือ ชื่อผู้ใช้</h4>
          </label>
          <input type="text" class="form-control" placeholder="อีเมลหรือชื่อผู้ใช้งาน" name="email_user">
          <label class="" style="padding-top:20px;">
            <h4>ระบบจะทำการส่งการดำเนินการไปยังอีเมลของท่าน<br>กรุณาตรวจสอบอีเมลของท่าน หากไม่พบกรุณาตรวจสอบที่อีเมลขยะ</h4>
          </label>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">ยกเลิก</button>
        <button type="submit" class="btn btn-success">ดำเนินการต่อ</button>
      </div>
    </form>
    </div>
  </div>
</div>
<!-- </form> -->
<div class="modal fade modal-danger" id="alert">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h3 class="modal-title">แจ้งเตือน!</h3>
      </div>
      <form id="modal_form">
      <div class="modal-body">
        <h4>ชื่อผู้ใช้งานหรือรหัสผ่านไม่ถูกต้อง กรุณากรอกข้อมูลใหม่</h4>
      </div>
      <div class="modal-footer">

      </div>
    </form>
    </div>
  </div>
</div>

<!-- jQuery 2.1.4 -->
<script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
<!-- Bootstrap 3.3.5 -->
<script src="bootstrap/js/bootstrap.min.js"></script>
<!-- iCheck -->
<script src="plugins/iCheck/icheck.min.js"></script>

<script>
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' // optional
    });
  });
</script>
