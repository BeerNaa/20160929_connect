<?php
session_start();
include ("connect.php");

$getCheckBox = $_POST["select"];
$session = $_SESSION['userID'];

for($i=0; $i< count($getCheckBox); $i++){
  if($getCheckBox[$i]!=''){
    $sql = "DELETE FROM crops WHERE CROPS_ID='$getCheckBox[$i]'";
    $result = mysql_query($sql);
    // echo $sql;
  }
}

if($result){
  echo "<meta http-equiv='refresh' content='0; url=crops.php'>" ;
  exit();
}
echo "<meta http-equiv='refresh' content='0; url=crops.php'>" ;
?>
