<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="index/css/bootstrap.css" media="screen">
    <script type="text/javascript" src="index/js/jquery-1.10.2.min.js"></script>
    <script type="text/javascript" src="index/js/bootstrap.min.js"></script>

    <style>

    .body {
            background: url(images/wallpaper_index.jpg) no-repeat center center fixed;
            -webkit-background-size: cover;
            -moz-background-size: cover;
            -o-background-size: cover;
            background-size: cover;
      }

    </style>
  </head>

  <div class="site-wrapper">
    <div class="site-wrapper-inner">
      <div class="cover-container">
        
      </div>
  </div>
  </div>
