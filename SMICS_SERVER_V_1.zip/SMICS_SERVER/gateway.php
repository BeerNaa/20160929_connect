<?php
session_start();
if($_SESSION['username'] == ''){
  echo "<meta http-equiv='refresh' content='0; url=index.php'>" ;
  exit();
}
include('header.php');
include('sidebar.php');
include('connect.php');
?>
<title>SMICS | GATEWAY</title>
<script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>

<script type="text/javascript">
function checkAll(bx) {
  var cbs = document.getElementsByTagName('input');
  for(var i=0; i < cbs.length; i++) {
    if(cbs[i].type == 'checkbox') {
      cbs[i].checked = bx.checked;
    }
  }
}

$(function(){
 $('.push').click(function(){
    var SQLvalID = $(this).attr('id');
     $.ajax({
        type : 'POST',
         url : 'ajaxEditGateway.php',
        data : 'G_ID='+SQLvalID,
     success : function(data){
            $('#valDataGateway').show().html(data);
            console.log(data);
         }
       });
  });
  document.body.removeAttribute("style");
});

function myFunction2() {
    $('#valEditGateway').modal('hide');
  //  $('.modal.in')
  //  $( '.modal' ).remove();
    document.body.removeAttribute("style");
}
function myFunction3() {
    $('#myModal').modal('show');
  //  $('.modal.in')
  //  $( '.modal' ).remove();
    document.body.removeAttribute("style");
}
function myFunction4() {
    $('#myModal').modal('hide');
  //  $('.modal.in')
  //  $( '.modal' ).remove();
    document.body.removeAttribute("style");
}
</script>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Gateway Management
    </h1>
    <div style="padding-top:20px;"></div>
    <a class="btn btn-primary" onclick="myFunction3()"><i class="fa fa-plus" aria-hidden="true"></i>&nbsp;&nbsp;เพิ่มข้อมูลเกทเวย์ของฉัน</a>
    <div style="padding-top:20px;"></div>
  </section>

  <form action="delete_gateway.php" method="post">
  <table class="table table-striped table-hover ">
    <thead>
      <tr>
        <th width="150px;"><center>เลือกทั้งหมด<br><input type="checkbox" onclick="checkAll(this)" ></center></th>
        <?php
          $session_status = $_SESSION['status'];
          if ($session_status == "Administrator") { ?>
            <th width="100px;" style="text-align: center;">รหัสผู้ใช้</th>
          <?php }
          else {
            ?>
            <th width="100px;" style="text-align: center;">ลำดับ</th>
            <?php
          }
        ?>
        <th width="200px;" style="text-align: center;">ชื่อของเกทเวย์</th>
        <th width="100px;" style="text-align: center;">คีย์</th>
        <th width="100px;" style="text-align: center;">แอดเดรส</th>
        <th width="100px;" style="text-align: center;">แก้ไข</th>
      </tr>
    </thead>
    <tbody style="text-align: center;">
    <?php
      $count = 1;
      $session_userID = $_SESSION['userID'];
      if($session_status == "Administrator"){
        $sql = "select G_ID, G_NAME, G_KEY, PIPES, USER_ID from gateway";
      }
      else {
        $sql = "select G_ID, G_NAME, G_KEY, PIPES, USER_ID from gateway where USER_ID = '$session_userID'";
      }
      $result = mysql_query($sql);
      while($row = mysql_fetch_array($result)){
    ?>
      <tr>
        <td>
          <center>
            <input type="checkbox" name="select_gateway[]" value = "<?php echo $row["G_ID"]; ?>">
          </center>

        </td>
        <?php
          if ($session_status == "Administrator") { ?>
            <td><?php echo $row["G_ID"]; ?></td>
          <?php }
          else {
            ?>
            <td><?php echo $count; ?></td>
            <?php
          }
        ?>
        <td><?php echo $row["G_NAME"]; ?></td>
        <td><?php echo $row["G_KEY"]; ?></td>
        <td><?php echo $row["PIPES"]; ?></td>
        <td>
          <a class="btn btn-warning btn-xs push" data-toggle="modal" data-target="#valEditGateway" id="<?php echo $row["G_ID"]; ?>"><i class="fa fa-pencil"></i>&nbsp;&nbsp;แก้ไข</a>
        </td>
      </tr>
    <?php $count++; } ?>
    </tbody>
  </table>
  <!-- <section class="content-header"> -->
  <section class="content-header">
    <button type="submit" class="btn btn-danger" onclick="return confirm('คุณแน่ใจหรือไม่ที่จะลบข้อมูล?');"><i class="fa fa-trash"></i>&nbsp;&nbsp;ลบรายการที่เลือก</button>
    <div style="padding-top:30px;"></div>
  </section>
  <!-- </section> -->
</form>

  <!-- Main content -->
  <section class="content">
    <!-- Small boxes (Stat box) -->

  </section><!-- /.content -->
</div><!-- /.content-wrapper -->

<div class="modal fade modal-primary" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title">เพิ่มข้อมูลเกทเวย์ของฉัน</h4>
      </div>
      <form id="modal_form" action="insert_gateway.php" method="post">
      <div class="modal-body">
        <div class="row">
          <div class="col-md-12">
            <label class="">
              <h4>ชื่อเกทเวย์</h4>
            </label>
            <input type="text" class="form-control" placeholder="กรุณาระบชื่อุเกทเวย์" name="gname_ins" required="">
            <label class="">
            </div>
          </div>
          <div class="row">
            <div class="col-md-6">
          <label class="" style="padding-top:5px;">
            <h4>คีย์</h4>
          </label>
          <input type="text" class="form-control" placeholder="กรุณาระบุคีย์ของเกทเวย์" name="gkey_ins" required="">
        </div>
        <div class="col-md-6">
          <label class="" style="padding-top:5px;">
            <h4>แอดเดรส</h4>
          </label>
          <input type="text" class="form-control" placeholder="กรุณาระบุแอดเดรสของเกทเวย์" name="gaddress_ins" required="">
        </div>
        </div>
      </div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-success">บันทึกการทำรายการ</button>
        <button type="button" class="btn btn-danger" onclick="myFunction4()">ยกเลิก</button>
      </div>
    </form>
    </div>
  </div>

  <form action="edit_gateway.php" method="post">
  <div class="modal fade" name="valEditGateway" id="valEditGateway" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title"><i class="fa fa-pencil"></i>&nbsp;&nbsp;แก้ไขข้อมูลเกทเวย์</h4>
        </div>
        <div class="modal-body table-responsive">
          <form role="form" name="editCatalogue" action="editCatalogue.php" method="post" enctype="multipart/form-data">
            <?php echo '<input type="hidden" name="instant" value="editCatalogue">'; //Form Instant ?>

            <div id="valDataGateway"></div>

            <div class="pull-right padding">
              <button type="submit" id="submit" name="submit" class="btn btn-success"> ดำเนินการแก้ไข</button>
              <button type="button" id="cancle" name="cancle" class="btn btn-danger" onclick="myFunction2()"> ยกเลิก</button>
            </div>
          </form>
        </div>
      </div>
      </div>
      </div>
      </form>

<?php
include('footer.php');
?>
