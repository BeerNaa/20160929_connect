<?php
session_start();
include ("connect.php");

$getUsername = $_POST["username"];
$getEmail = $_POST["e-mail"];
$getFirstName = $_POST["firstname"];
$getLastName = $_POST["lastname"];
$session = $_SESSION['userID'];

$sql = "UPDATE `user` SET `email`='$getEmail',`username`='$getUsername',`firstName`= '$getFirstName',`lastName`= '$getLastName' WHERE userID = '$session'";
$result = mysql_query($sql);

if($result){
  $_SESSION['firstName'] = $getFirstName;
  $_SESSION['lastName'] = $getLastName;
  echo "<meta http-equiv='refresh' content='0; url=profile_setting.php'>" ;
  exit();
}
echo "<meta http-equiv='refresh' content='0; url=profile_setting.php'>" ;
?>
