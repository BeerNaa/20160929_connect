<?php
// session_start();
// include ("connect.php");

$getEmail_User = "dnnsur@gmail.com";//$_POST["email_user"];
// echo $getUsername;
$token = md5($getEmail_User);
//echo $token;
date_default_timezone_set('Asia/Bangkok');
$nowDate = date("Y-m-d H:i:s");
// echo $nowDate;

// Insert information to session database
// $sql = "INSERT INTO session (sessionID, status, session_Date, email, token) VALUES ('SES-0001', 1, '$nowDate', '$getEmail_User', '$token')";
// $result = mysql_query($sql);

// send email to member

/* DATA */
				$dataBody = '<table width="100%" border="0" align="left">';
				$dataBody .= '<tr>';
				$dataBody .= '<td><br/>เรียนคุณ ';
				$dataBody .= $getEmail_User.'<br/><br/>';
				$dataBody .= 'ทางเราพบว่า คุณพยายามทำการ Reset Password'.'<br/>';
				$dataBody .= 'เพื่อเป็นการยืนยันว่าคนที่ดำเนินการดังกล่าวเป็นคุณจริงๆ กรุณาคลิกลิงค์ด้านล่าง เพื่อดำเนินการ Reset Password'.'<br/>';
				$dataBody .= '<br/><a href="http://localhost/ISM/changePassword.php?token='.$token.'" target="_blank">';
				$dataBody .= 'ตั้งรหัสผ่านใหม่</a>'.'<br/>';
				$dataBody .= '<br/><br/>';
				$dataBody .= 'ขอแสดงความนับถือ<br/>';
				$dataBody .= '<br/><br/>';
				$dataBody .= '<hr/>';
				$dataBody .= 'อีเมลนี้เป็นการแจ้งจากระบบอัตโนมัติ กรุณาอย่าตอบกลับ';
				$dataBody .= '</td>';
				$dataBody .= '</tr>';

				$dataBody .= '</table>';

        sendMail($dataBody, $getEmail_User);
?>

<?php
function sendMail($data, $toEmail){
	require_once('class.phpmailer.php');
	$mail = new PHPMailer();
	$mail->IsHTML(true);
	$mail->IsSMTP();
	$mail->SMTPAuth = true; // enable SMTP authentication
	$mail->SMTPSecure = "tls"; // sets the prefix to the servier
	$mail->Host = "smtp.gmail.com"; // sets GMAIL as the SMTP server
	$mail->Port = 587; // set the SMTP port for the GMAIL server
	$mail->Username = "surasak.hanl@gmail.com"; // surasak.hanl@gmail.com
	$mail->Password = "2037Ngip";
	$mail->From = "surasak.hanl@gmail.com"; // "surasak.hanl@gmail.com";
	$mail->FromName = "ทดสอบ";  // set from Name
	$mail->Subject = "ตั้งค่ารหัสผ่านใหม่";
	$mail->Body = $data;
	$mail->AddAddress($toEmail); // to Address
	$mail->set('X-Priority', '1'); //Priority 1 = High, 3 = Normal, 5 = low
	$mail->Send();
	} ?>
