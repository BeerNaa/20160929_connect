<?php
  $pass = "123";
  $password_encrypt = md5($pass);
  echo $password_encrypt;
?>
