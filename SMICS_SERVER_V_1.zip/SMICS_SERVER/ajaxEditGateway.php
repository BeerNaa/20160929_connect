<?php

// require_once ("secure.php"); // Page Security
include ("connect.php");

$getCallID= (isset($_POST['G_ID'])) ? $_POST['G_ID'] : '';
$sql = "SELECT * FROM gateway WHERE G_ID = '$getCallID'";
$result = mysql_query($sql);
$row = mysql_fetch_array($result);
?>
<form method="post">
<div class="box-body">
  <input type="hidden" name="GID" value="<?php echo $getCallID; ?>">
    <div class="row">
        <div class="col-md-12">
          <div class="form-group">
            <h4>ชื่อเกทเวย์</h4>
            <input class="form-control" type="text" name="GName_edit" id="GName"
            title="ชื่อพืช" required="" value="<?php echo $row["G_NAME"]; ?>">
          </div>
        </div>
    </div>
    <div class="row">
      <div class="col-md-6">
        <div class="form-group">
          <h4>คีย์</h4>
          <input class="form-control" type="text" name="GKey_edit" id="moisture"
          title="ปริมาณความชื้น" required="" value="<?php echo $row["G_KEY"]; ?>">
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
          <h4>แอดเดรส</h4>
          <input class="form-control" type="text" name="GAddress_edit" id="season"
          title="ชื่อพืช" required="" value="<?php echo $row["PIPES"]; ?>">
        </div>
      </div>
    </div>
    </div><!-- /.div row -->
</form>
