<?php
session_start();
include ("connect.php");

$getCropsID = $_POST["cropsID"];
$getcropsName = $_POST["cropsName"];
$getTypeCrops = $_POST["type_crops"];
$getMoisture = $_POST["moisture"];
$getSeason = $_POST["season"];
$session = $_SESSION['userID'];

$sql = "UPDATE `crops` SET `CROPS_NAME`='$getcropsName',`MOISTURE`='$getMoisture',`SEASON`='$getSeason',`TYPE_ID`= '$getTypeCrops' WHERE USER_ID = '$session' && CROPS_ID = '$getCropsID'";
$result = mysql_query($sql);

if($result){
  echo "<meta http-equiv='refresh' content='0; url=crops.php'>" ;
  exit();
}
echo "<meta http-equiv='refresh' content='0; url=crops.php'>" ;
?>
