<?php
$valKey = $_GET['valID'];
date_default_timezone_set('Asia/Bangkok');
?>
<div class="row">
  <div class="col-md-12">
    <?php
      $sql = "SELECT * FROM gateway WHERE G_ID = '$valKey'";
      $result = mysql_query($sql);
      $row = mysql_fetch_array($result);
    ?>
    <h4 class=""><?php echo strtoupper($row['G_NAME']) ?>
      <!-- (<?php echo $row["PIPES"] ?>) -->
    </h4>
  </div>
</div>
<div class="row" style="padding-top: 20px;">
  <div class="col-md-6">
    <div class="row">
      <div class="col-md-12">
        <div class="">
          <?php
            $sqlGateway = "SELECT * FROM gateway WHERE G_ID = '$valKey'";
            $resultGateway = mysql_query($sqlGateway);
            $rowGateway = mysql_fetch_array($resultGateway);

            //echo strtoupper($rowGateway['GName']);

          ?>
        </div>
        <div class="box" >
          <div class="box-header with-border">
            <h3 class="box-title" id="date"></h3>
            <div class="box-tools pull-right">
              <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
              <div class="btn-group">
                <button class="btn btn-box-tool dropdown-toggle" data-toggle="dropdown"><i class="fa fa-wrench"></i></button>
                <ul class="dropdown-menu" role="menu">
                  <li><a href="#">Action</a></li>
                  <li><a href="#">Another action</a></li>
                  <li><a href="#">Something else here</a></li>
                  <li class="divider"></li>
                  <li><a href="#">Separated link</a></li>
                </ul>
              </div>
              <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
            </div>
          </div><!-- /.box-header -->
          <div class="box-body">
            <div class="row">
              <div class="col-md-12">
                <p class="text-center">
                  <strong id="date" >
                    <script>
                      var date = new Date().getDay()
                      var day
                      var month
                      switch(new Date().getDay()) {
                        case 0:
                            day = "อาทิตย์";
                            break;
                        case 1:
                            day = "จันทร์";
                            break;
                        case 2:
                            day = "อังคาร";
                            break;
                        case 3:
                            day = "พุธ";
                            break;
                        case 4:
                            day = "พฤหัสบดี";
                            break;
                        case 5:
                            day = "ศุกร์";
                        case 6:
                            day = "เสาร์";
                            break;
                      }
                      switch(new Date().getMonth()) {
                        case 0:
                            month = "มกราคม";
                            break;
                        case 1:
                            month = "กุมภาพันธ์";
                            break;
                        case 2:
                            month = "มีนาคม";
                            break;
                        case 3:
                            month = "เมษายน";
                            break;
                        case 4:
                            month = "พฤษภาคม";
                            break;
                        case 5:
                            month = "มิถุนายน";
                            break;
                        case 6:
                            month = "กรกฎาคม";
                            break;
                        case 7:
                            month = "สิงหาคม";
                            break;
                        case 8:
                            month = "กันยายน";
                            break;
                        case 9:
                            month = "ตุลาคม";
                            break;
                        case 10:
                            month = "พฤศจิกายน";
                            break;
                        case 11:
                            month = "ธันวาคม";
                            break;
                      }
                      document.getElementById("date").innerHTML = "สถิตประจำวัน : "+day+" ที่ "+(new Date().getDate())+" "+month+" "+(new Date().getFullYear()+543);
                    </script>
                  </strong>
                </p>
                <div class="chart">
                  <!-- Sales Chart Canvas -->
                  <canvas id="salesChart_day<?php echo $count; ?>" style="height: 100px;"></canvas>
                </div><!-- /.chart-responsive -->
              </div><!-- /.col -->
              <div class="col-md-4" style="display:none;">
                <p class="text-center">
                  <strong>Goal Completion</strong>
                </p>
                <div class="progress-group">
                  <span class="progress-text">Add Products to Cart</span>
                  <span class="progress-number"><b>160</b>/200</span>
                  <div class="progress sm">
                    <div class="progress-bar progress-bar-aqua" style="width: 80%"></div>
                  </div>
                </div><!-- /.progress-group -->
                <div class="progress-group">
                  <span class="progress-text">Complete Purchase</span>
                  <span class="progress-number"><b>310</b>/400</span>
                  <div class="progress sm">
                    <div class="progress-bar progress-bar-red" style="width: 80%"></div>
                  </div>
                </div><!-- /.progress-group -->
                <div class="progress-group">
                  <span class="progress-text">Visit Premium Page</span>
                  <span class="progress-number"><b>480</b>/800</span>
                  <div class="progress sm">
                    <div class="progress-bar progress-bar-green" style="width: 80%"></div>
                  </div>
                </div><!-- /.progress-group -->
                <div class="progress-group">
                  <span class="progress-text">Send Inquiries</span>
                  <span class="progress-number"><b>250</b>/500</span>
                  <div class="progress sm">
                    <div class="progress-bar progress-bar-yellow" style="width: 80%"></div>
                  </div>
                </div><!-- /.progress-group -->
              </div><!-- /.col -->
            </div><!-- /.row -->
          </div><!-- ./box-body -->
        </div><!-- /.box -->
        <div class="box">
          <div class="box-header with-border">
            <h3 class="box-title" id="week"></h3>
            <div class="box-tools pull-right">
              <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
              <div class="btn-group">
                <button class="btn btn-box-tool dropdown-toggle" data-toggle="dropdown"><i class="fa fa-wrench"></i></button>
                <ul class="dropdown-menu" role="menu">
                  <li><a href="#">Action</a></li>
                  <li><a href="#">Another action</a></li>
                  <li><a href="#">Something else here</a></li>
                  <li class="divider"></li>
                  <li><a href="#">Separated link</a></li>
                </ul>
              </div>
              <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
            </div>
          </div><!-- /.box-header -->
          <div class="box-body">
            <div class="row">
              <div class="col-md-12">
                <p class="text-center">
                  <strong id="week">
                    <script>

                      var date = new Date().getDate(+1);
                      var day
                      var month
                      switch(new Date().getDay()) {
                        case 0:
                            day = "อาทิตย์";
                            break;
                        case 1:
                            day = "จันทร์";
                            break;
                        case 2:
                            day = "อังคาร";
                            break;
                        case 3:
                            day = "พุธ";
                            break;
                        case 4:
                            day = "พฤหัสบดี";
                            break;
                        case 5:
                            day = "ศุกร์";
                        case 6:
                            day = "เสาร์";
                            break;
                      }
                      switch(new Date().getMonth()) {
                        case 0:
                            month = "มกราคม";
                            break;
                        case 1:
                            month = "กุมภาพันธ์";
                            break;
                        case 2:
                            month = "มีนาคม";
                            break;
                        case 3:
                            month = "เมษายน";
                            break;
                        case 4:
                            month = "พฤษภาคม";
                            break;
                        case 5:
                            month = "มิถุนายน";
                            break;
                        case 6:
                            month = "กรกฎาคม";
                            break;
                        case 7:
                            month = "สิงหาคม";
                            break;
                        case 8:
                            month = "กันยายน";
                            break;
                        case 9:
                            month = "ตุลาคม";
                            break;
                        case 10:
                            month = "พฤศจิกายน";
                            break;
                        case 11:
                            month = "ธันวาคม";
                            break;
                      }
                      var today = new Date();
                      var dayOfWeekStartingSundayZeroIndexBased = today.getDay(); // 0 : Sunday ,1 : Monday,2,3,4,5,6 : Saturday
                      var mondayOfWeek = new Date(today.getFullYear(), today.getMonth(), today.getDate() - today.getDay());
                      var sundayOfWeek = new Date(today.getFullYear(), today.getMonth(), today.getDate() - today.getDay()+6);
                      // alert( mondayOfWeek );
                      // alert( sundayOfWeek );

                      var sundayOfWeek_day = mondayOfWeek.toString().substr(0, 3);
                      //alert( mondayOfWeek2 );
                      var saturdayOfWeek_day = sundayOfWeek.toString().substr(0, 3);
                      //alert( sundayOfWeek2 );

                      var sundayOfWeek_date = mondayOfWeek.toString().substr(8, 8);
                      var sunday_date = sundayOfWeek_date.toString().substr(0, 2);
                      // alert( sunday_date );
                      var saturdayOfWeek_date = sundayOfWeek.toString().substr(8, 8);
                      var saturday_date = saturdayOfWeek_date.toString().substr(0, 2);
                      // alert( saturday_date );

                      var day_begin
                      var day_end

                      switch(sundayOfWeek_day) {
                        case "Sun":
                            day_begin = "อาทิตย์";
                            break;
                        case "Sat":
                            day_begin = "เสาร์";
                            break;
                      }
                      switch(saturdayOfWeek_day) {
                        case "Sun":
                            day_end = "อาทิตย์";
                            break;
                        case "Sat":
                            day_end = "เสาร์";
                            break;
                      }

                      var sundayOfWeek_month = mondayOfWeek.toString().substr(4, 4);
                      // alert( sundayOfWeek_month );
                      var saturdayOfWeek_month = sundayOfWeek.toString().substr(4, 4);
                      // alert( saturdayOfWeek_month );

                      var month_begin
                      var month_end

                      switch(sundayOfWeek_month) {
                        case "Jan ":
                            month_begin = "มกราคม";
                            break;
                        case "Feb ":
                            month_begin = "กุมภาพันธ์";
                            break;
                        case "Mar ":
                            month_begin = "มีนาคม";
                            break;
                        case "Apr ":
                            month_begin = "เมษายน";
                            break;
                        case "May ":
                            month_begin = "พฤษภาคม";
                            break;
                        case "Jun ":
                            month_begin = "มิถุนายน";
                            break;
                        case "Jul ":
                            month_begin = "กรกฎาคม";
                            break;
                        case "Aug ":
                            month_begin = "สิงหาคม";
                            break;
                        case "Sep ":
                            month_begin = "กันยายน";
                            break;
                        case "Oct ":
                            month_begin = "ตุลาคม";
                            break;
                        case "Nov ":
                            month_begin = "พฤศจิกายน";
                            break;
                        case "Dec ":
                            month_begin = "ธันวาคม";
                            break;
                      }
                      switch(saturdayOfWeek_month) {
                        case "Jan ":
                            month_end = "มกราคม";
                            break;
                        case "Feb ":
                            month_end = "กุมภาพันธ์";
                            break;
                        case "Mar ":
                            month_end = "มีนาคม";
                            break;
                        case "Apr ":
                            month_end = "เมษายน";
                            break;
                        case "May ":
                            month_end = "พฤษภาคม";
                            break;
                        case "Jun ":
                            month_end = "มิถุนายน";
                            break;
                        case "Jul ":
                            month_end = "กรกฎาคม";
                            break;
                        case "Aug ":
                            month_end = "สิงหาคม";
                            break;
                        case "Sep ":
                            month_end = "กันยายน";
                            break;
                        case "Oct ":
                            month_end = "ตุลาคม";
                            break;
                        case "Nov ":
                            month_end = "พฤศจิกายน";
                            break;
                        case "Dec ":
                            month_end = "ธันวาคม";
                            break;
                      }

                      document.getElementById("week").innerHTML = "สถิตประจำสัปดาห์ : "+sunday_date+" "+month_begin+" - "+saturday_date+" "+month_end+" "+(new Date().getFullYear()+543);
                    </script>
                  </strong>
                </p>
                <div class="chart">
                  <!-- Sales Chart Canvas -->
                  <canvas id="salesChart_week<?php echo $count; ?>" style="height: 100px;"></canvas>
                </div><!-- /.chart-responsive -->
              </div><!-- /.col -->
              <div class="col-md-4" style="display:none;">
                <p class="text-center">
                  <strong>Goal Completion</strong>
                </p>
                <div class="progress-group">
                  <span class="progress-text">Add Products to Cart</span>
                  <span class="progress-number"><b>160</b>/200</span>
                  <div class="progress sm">
                    <div class="progress-bar progress-bar-aqua" style="width: 80%"></div>
                  </div>
                </div><!-- /.progress-group -->
                <div class="progress-group">
                  <span class="progress-text">Complete Purchase</span>
                  <span class="progress-number"><b>310</b>/400</span>
                  <div class="progress sm">
                    <div class="progress-bar progress-bar-red" style="width: 80%"></div>
                  </div>
                </div><!-- /.progress-group -->
                <div class="progress-group">
                  <span class="progress-text">Visit Premium Page</span>
                  <span class="progress-number"><b>480</b>/800</span>
                  <div class="progress sm">
                    <div class="progress-bar progress-bar-green" style="width: 80%"></div>
                  </div>
                </div><!-- /.progress-group -->
                <div class="progress-group">
                  <span class="progress-text">Send Inquiries</span>
                  <span class="progress-number"><b>250</b>/500</span>
                  <div class="progress sm">
                    <div class="progress-bar progress-bar-yellow" style="width: 80%"></div>
                  </div>
                </div><!-- /.progress-group -->
              </div><!-- /.col -->
            </div><!-- /.row -->
          </div><!-- ./box-body -->
        </div><!-- /.box -->
      </div><!-- /.row -->
    </div>
    <div class="row">
      <div class="col-md-12">
        <div class="box">
          <div class="box-header with-border">
            <h3 class="box-title" id="month"></h3>
            <div class="box-tools pull-right">
              <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
              <div class="btn-group">
                <button class="btn btn-box-tool dropdown-toggle" data-toggle="dropdown"><i class="fa fa-wrench"></i></button>
                <ul class="dropdown-menu" role="menu">
                  <li><a href="#">Action</a></li>
                  <li><a href="#">Another action</a></li>
                  <li><a href="#">Something else here</a></li>
                  <li class="divider"></li>
                  <li><a href="#">Separated link</a></li>
                </ul>
              </div>
              <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
            </div>
          </div><!-- /.box-header -->
          <div class="box-body">
            <div class="row">
              <div class="col-md-12">
                <p class="text-center">
                  <strong >
                    <script>
                      document.getElementById("month").innerHTML = "สถิตประจำเดือน : มกราคม - ธันวาคม "+(new Date().getFullYear()+543);
                    </script>
                  </strong>
                </p>
                <div class="chart">
                  <!-- Sales Chart Canvas -->
                  <canvas id="salesChart<?php echo $count; ?>" style="height: 150px;"></canvas>
                </div><!-- /.chart-responsive -->
              </div><!-- /.col -->
              <div class="col-md-4" style="display:none;">
                <p class="text-center">
                  <strong>Goal Completion</strong>
                </p>
                <div class="progress-group">
                  <span class="progress-text">Add Products to Cart</span>
                  <span class="progress-number"><b>160</b>/200</span>
                  <div class="progress sm">
                    <div class="progress-bar progress-bar-aqua" style="width: 80%"></div>
                  </div>
                </div><!-- /.progress-group -->
                <div class="progress-group">
                  <span class="progress-text">Complete Purchase</span>
                  <span class="progress-number"><b>310</b>/400</span>
                  <div class="progress sm">
                    <div class="progress-bar progress-bar-red" style="width: 80%"></div>
                  </div>
                </div><!-- /.progress-group -->
                <div class="progress-group">
                  <span class="progress-text">Visit Premium Page</span>
                  <span class="progress-number"><b>480</b>/800</span>
                  <div class="progress sm">
                    <div class="progress-bar progress-bar-green" style="width: 80%"></div>
                  </div>
                </div><!-- /.progress-group -->
                <div class="progress-group">
                  <span class="progress-text">Send Inquiries</span>
                  <span class="progress-number"><b>250</b>/500</span>
                  <div class="progress sm">
                    <div class="progress-bar progress-bar-yellow" style="width: 80%"></div>
                  </div>
                </div><!-- /.progress-group -->
              </div><!-- /.col -->
            </div><!-- /.row -->
          </div><!-- ./box-body -->
        </div><!-- /.box -->
      </div><!-- /.col -->
    </div><!-- /.row -->
  </div>
  <div class="col-md-6">

<?php
  $sqlSensor = "SELECT * FROM sensor_node WHERE G_ID = '$valKey'";
  $resultSensor = mysql_query($sqlSensor);
  $count = 0;
  $array = array("bg-aqua", "bg-maroon", "bg-gray", "bg-navy", "bg-yellow", "bg-olive","bg-purple", "bg-red", "bg-teal");
  // echo $sqlSensor;
  while ($rowSensor = mysql_fetch_array($resultSensor)) { ?>
    <?php
      $valSID = $rowSensor['S_ID'];
      $sqlEnergy = "SELECT * FROM battery WHERE S_ID = '$valSID'";
      $resultEnergy = mysql_query($sqlEnergy);
      $rowEnergy = mysql_fetch_array($resultEnergy);

      $sqlMoisture = "SELECT * FROM moisture WHERE S_ID = '$valSID'";
      $resultMoisture = mysql_query($sqlMoisture);
      $rowMoisture = mysql_fetch_array($resultMoisture)
    ?>
    <div class="info-box <?php echo $array[$count%5]?>">
      <span class="info-box-icon" style="padding-top: 22px; padding-right: 5px"><i class="ion-paper-airplane"></i></span>
      <div class="info-box-content">
        <span class="info-box-text" style="padding-top: 35px;"><?php echo $rowSensor["S_NAME"] ?></span>
        <span class="progress-description" style="padding-top: 40px;">ปริมาณแบตเตอรี่คงเหลือ (<?php echo  $rowEnergy['E_BALANCE'];?>%)</span>
        <div class="progress">
          <div class="progress-bar" style="width: <?php echo $rowEnergy['E_BALANCE']; ?>%"></div>
        </div>
        <span class="progress-description" style="padding-top: 10px;">ปริมาณความชื้น (<?php echo  $rowMoisture['MOISTURES'];?>%)</span>
        <div class="progress">
          <div class="progress-bar" style="width: <?php echo $rowMoisture['MOISTURES']; ?>%"></div>
        </div>
        <span class="progress-description">
          &nbsp;
        </span>
      </div><!-- /.info-box-content -->
    </div><!-- /.info-box -->
  <?php $count++; }
?>

  </div>
</div>
