<?php
session_start();
if($_SESSION['username'] == ''){
  echo "<meta http-equiv='refresh' content='0; url=index.php'>" ;
  exit();
}
include('connect.php');
include('header.php');
include('sidebar.php');
?>

<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<!-- Bootstrap 3.3.5 -->
<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
<!-- Font Awesome -->
<link rel="stylesheet" href="css/font-awesome.min.css">
<!-- Ionicons -->
<link rel="stylesheet" href="css/ionicons.min.css">
<!-- jvectormap -->
<link rel="stylesheet" href="plugins/jvectormap/jquery-jvectormap-1.2.2.css">
<!-- Theme style -->
<link rel="stylesheet" href="dist/css/AdminLTE.min.css">
<!-- AdminLTE Skins. Choose a skin from the css/skins
folder instead of downloading all of them to reduce the load. -->
<link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">

<script type="text/javascript" src="js/canvasjs.min.js"></script>

<title>SMICS | DASHBOARD</title>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Dashboard
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
      <!-- <li class="active">Dashboard</li> -->
    </ol>
  </section>
  <!-- Main content -->

<!-- <div id="chartContainer" style="height: 300px; width: 100%;"></div> -->

  <section class="content">

    <fieldset>
      <form class="form-horizontal">
        <div class="form-group">
          <label for="inputEmail" class="col-lg-3 control-label">กรุณาเลือกเกตเวย์ของคุณ</label>
          <div class="col-lg-8">
            <select onchange="if (this.value) window.location.href=this.value" name="val" id="val" required="" class="form-control">
              <option value="">Please Select...</option>
              <?php
                  $tempSession = $_SESSION['userID'];
                  $sqlData = "SELECT * FROM gateway WHERE USER_ID = '$tempSession'";
                  $resultData = mysql_query($sqlData);
                  while($rowData = mysql_fetch_array($resultData)){
                    echo '<option value="home.php?valID='.$rowData['G_ID'].'">'.strtoupper($rowData['G_NAME']).'</option>';
                  }
              ?>
            </select>
          </div>
        </div>
      </form>
    </fieldset>

    <!-- Small boxes (Stat box) -->
    <!-- <section class="content"> -->
    <!-- <div class=""> -->
    <div class="">
      <h3 class="box-title"></h3>
    </div>

      <?php
      /*

      /* GATEWAY */

      //Permission session

      /*
      $tempSession = $_SESSION['userID'];
      $sqlGate = "SELECT * FROM gateway WHERE userID = '$tempSession'";
      echo $sqlGate;
      $resultGate = mysql_query($sqlGate);
      $count = 0;
      while ($rowGate = mysql_fetch_array($resultGate)) { ?>
      <?php $count++; }

      */ ?>

      <?php
        //Div controller
        $getID = (isset($_GET['valID'])) ? $_GET['valID'] : '';
        if($getID == ""){
          $divCtrl = "display:none;";
        } else {
          $divCtrl = "display:block;";
        }

      ?>

      <div id="showDynamic" style="<?php echo $divCtrl; ?>">
        <?php include('dynamicData.php'); ?>
      </div>

    <!-- </div> -->
    <!-- </section> --> <!-- /.content -->
  </section><!-- /.content -->
</div><!-- /.content-wrapper -->
<?php
include('footer.php');
?>
