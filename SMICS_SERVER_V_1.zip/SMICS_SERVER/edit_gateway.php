<?php
session_start();
include ("connect.php");

$getGID = $_POST["GID"];
$getGName = $_POST["GName_edit"];
$getGKey = $_POST["GKey_edit"];
$getGAddress = $_POST["GAddress_edit"];
$session = $_SESSION['userID'];

$sql = "UPDATE `gateway` SET `G_NAME`='$getGName',`G_KEY`='$getGKey',`PIPES`= '$getGAddress' WHERE USER_ID = '$session' && G_ID = '$getGID'";
$result = mysql_query($sql);

if($result){
  echo "<meta http-equiv='refresh' content='0; url=gateway.php'>" ;
  exit();
}
echo "<meta http-equiv='refresh' content='0; url=gateway.php'>" ;
?>
