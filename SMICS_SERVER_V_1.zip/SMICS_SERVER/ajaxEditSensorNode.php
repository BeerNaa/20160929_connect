<?php

// require_once ("secure.php"); // Page Security
include ("connect.php");

$getCallID = (isset($_POST['S_ID'])) ? $_POST['S_ID'] : '';
$sql = "SELECT * FROM sensor_node WHERE S_ID = '$getCallID'";
$result = mysql_query($sql);
$row = mysql_fetch_array($result);
?>
<form method="post">
<div class="box-body">
  <input type="hidden" name="S_ID" value="<?php echo $getCallID; ?>">
    <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <h4>ชื่อเซนเซอร์โหนด</h4>
            <input class="form-control" type="text" name="S_NAME_edit" id="S_NAME_edit"
            title="ชื่อพืช" required="" value="<?php echo $row["S_NAME"]; ?>">
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <h4>คีย์</h4>
            <input class="form-control" type="text" name="S_KEY_edit" id="S_KEY_edit"
            title="ปริมาณความชื้น" required="" value="<?php echo $row["S_KEY"]; ?>">
          </div>
        </div>
    </div>
    </div><!-- /.div row -->
</form>
